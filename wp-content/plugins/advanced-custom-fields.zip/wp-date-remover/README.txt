=== WP Date Remover ===
Contributors: selmam
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=HDDZC67MECKQQ
Tags: Remove Time And Date, Date Information, Date, Posting Date, Remove, Remover, Entry-Meta, Free, Post, Posts, Category, Categories, Specific Post Categories, WP Date Remover, Timeless, Timeless Content, Evergreen
Requires at least: 4.0
Tested up to: 4.7.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The easiest way to remove the time and date from specific post categories.

== Description ==

WP Date Remover allows you to quickly and easily remove the time and date from specific post categories.

There are plenty of similar plugins out there – but what makes WP Date Remover unique – is that it allows you to remove the time and date from specific categories. This means you get to choose!

If you like this plugin, please rate it.

== Installation ==

To install the plugin, you can either use the built in automatic installer in WordPress or install the plugin manually.

= Install the plugin in WordPress: =
Go to Plugins => Add New => and search for: WP Date Remover
Press Install Now for the WP Date Remover plugin
Press Activate Plugin

= Install the plugin manually: =
Upload the WP Date Remover directory to the /wp-content/plugins/ directory
Activate the plugin through the Plugins menu in WordPress

= Configuring the plugin: =
Go to Settings => Wp Date Remover
Select the categories you want to hide time and date in
Click Update
You’re done

== Frequently Asked Questions ==

= I miss a feature, can you add it? =

Feel free to send me an email, if more people request the same feature I will add it.

== Screenshots ==

1. Before activation
2. After activation
3. Settings page

== Changelog ==

= 1.0.1 =
* Tested & found compatible with WP 4.7.2.

= 1.0.0 =
* First release

== Upgrade Notice ==

There is no need to upgrade just yet.

