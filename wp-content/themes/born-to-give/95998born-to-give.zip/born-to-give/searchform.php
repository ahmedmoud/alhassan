 <form method="get" id="searchform" action="<?php echo esc_url(home_url()); ?>/">
            <div class="input-group">
            <input type="text" class="form-control" name="s" id="s" value="" placeholder="<?php esc_html_e('Search Posts...','borntogive'); ?>" />
            <span class="input-group-btn">
            <button type ="submit" name ="submit" class="btn btn-primary"><i class="fa fa-search fa-lg"></i></button>
            </span> </div>
 </form>
